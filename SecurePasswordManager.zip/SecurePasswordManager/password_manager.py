import json
import os
from encryption import encrypt_password, decrypt_password

DATA_FILE = "data/passwords.json"

def load_data():
    if not os.path.exists("data"):
        os.makedirs("data")

    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w") as file:
            json.dump([], file)

    with open(DATA_FILE, "r") as file:
        return json.load(file)

def save_data(data):
    with open(DATA_FILE, "w") as file:
        json.dump(data, file, indent=4)

def add_password():
    website = input("Website/App Name: ")
    username = input("Username/Email: ")
    password = input("Password: ")

    encrypted_password = encrypt_password(password)

    data = load_data()

    data.append({
        "website": website,
        "username": username,
        "password": encrypted_password
    })

    save_data(data)

    print("Password Saved Successfully!")

def view_passwords():
    data = load_data()

    if not data:
        print("No saved passwords.")
        return

    for index, entry in enumerate(data, start=1):
        decrypted_password = decrypt_password(entry['password'])

        print(f"\nEntry {index}")
        print(f"Website : {entry['website']}")
        print(f"Username: {entry['username']}")
        print(f"Password: {decrypted_password}")

def search_password():
    website = input("Enter website/app name to search: ")

    data = load_data()

    found = False

    for entry in data:
        if entry['website'].lower() == website.lower():
            decrypted_password = decrypt_password(entry['password'])

            print("\nCredential Found")
            print(f"Username: {entry['username']}")
            print(f"Password: {decrypted_password}")

            found = True

    if not found:
        print("No matching credentials found.")

def delete_entry():
    website = input("Enter website/app name to delete: ")

    data = load_data()

    new_data = [entry for entry in data if entry['website'].lower() != website.lower()]

    if len(data) == len(new_data):
        print("No entry found.")
    else:
        save_data(new_data)
        print("Entry deleted successfully.")