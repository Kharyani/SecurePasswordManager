MASTER_PASSWORD = "admin123"

def login():
    print("===== Secure Password Manager =====")

    for attempt in range(3):
        password = input("Enter Master Password: ")

        if password == MASTER_PASSWORD:
            print("Access Granted!\n")
            return True
        else:
            print("Incorrect Password!")

    print("Too many failed attempts.")
    return False