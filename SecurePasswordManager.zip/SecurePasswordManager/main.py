from auth import login
from password_manager import (
    add_password,
    view_passwords,
    search_password,
    delete_entry
)
from generator import generate_password

def menu():
    while True:
        print("\n===== MENU =====")
        print("1. Add New Password")
        print("2. View Saved Passwords")
        print("3. Search Credentials")
        print("4. Delete Entry")
        print("5. Generate Strong Password")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            add_password()

        elif choice == '2':
            view_passwords()

        elif choice == '3':
            search_password()

        elif choice == '4':
            delete_entry()

        elif choice == '5':
            password = generate_password()
            print(f"Generated Password: {password}")

        elif choice == '6':
            print("Exiting Password Manager...")
            break

        else:
            print("Invalid choice!")

if __name__ == "__main__":
    if login():
        menu()