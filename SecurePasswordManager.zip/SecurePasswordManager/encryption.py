from cryptography.fernet import Fernet
import os

KEY_DIR = "keys"
KEY_FILE = os.path.join(KEY_DIR, "secret.key")

def generate_key():
    if not os.path.exists(KEY_DIR):
        os.makedirs(KEY_DIR)

    key = Fernet.generate_key()

    with open(KEY_FILE, "wb") as file:
        file.write(key)

def load_key():
    if not os.path.exists(KEY_FILE):
        generate_key()

    with open(KEY_FILE, "rb") as file:
        key = file.read()

    return key

key = load_key()
cipher = Fernet(key)

def encrypt_password(password):
    return cipher.encrypt(password.encode()).decode()

def decrypt_password(encrypted_password):
    return cipher.decrypt(encrypted_password.encode()).decode()